package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class UriArgTest {

    @Test
    fun roundTripsTypicalDocumentUris() {
        val uris = listOf(
            "content://com.android.providers.downloads.documents/document/msf%3A1234",
            "content://com.android.externalstorage.documents/document/primary%3ADocuments%2Fr%C3%A9sum%C3%A9.pdf",
            "file:///sdcard/a b/c.pdf?x=1&y=2#z",
        )
        uris.forEach { assertEquals(it, UriArg.decode(UriArg.encode(it))) }
    }

    @Test
    fun encodedFormContainsNoRouteBreakingCharacters() {
        val encoded = UriArg.encode("content://a/b/c?d=e&f=g#h")
        listOf('/', '?', '&', '#', '=', '%', '{', '}').forEach { assertFalse(encoded.contains(it)) }
    }
}
