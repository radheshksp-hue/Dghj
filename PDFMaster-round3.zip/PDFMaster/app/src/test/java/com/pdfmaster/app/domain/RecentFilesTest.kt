package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecentFilesTest {

    private fun file(name: String, size: Long = 100, opened: Long = 1, uri: String = "content://docs/$name") =
        RecentFile(uri, name, size, opened)

    @Test
    fun codecRoundTripsAwkwardNames() {
        val files = listOf(
            file("Résumé\tfinal\nversion.pdf", size = 2048, opened = 99, uri = "content://a/b?x=1&y=2#frag"),
            file("日本語.pdf", size = -1, opened = 5),
        )
        assertEquals(files, RecentFilesCodec.decode(RecentFilesCodec.encode(files)))
    }

    @Test
    fun decodeOfNothingIsEmpty() {
        assertTrue(RecentFilesCodec.decode(null).isEmpty())
        assertTrue(RecentFilesCodec.decode("").isEmpty())
        assertTrue(RecentFilesCodec.decode("   \n  ").isEmpty())
    }

    @Test
    fun decodeSkipsDamagedLinesButKeepsGoodOnes() {
        val good = file("good.pdf")
        val raw = "garbage line\n" + RecentFilesCodec.encode(listOf(good)) + "\na\tb\tnot-a-number\t1\n%zz\tb\t1\t1"
        assertEquals(listOf(good), RecentFilesCodec.decode(raw))
    }

    @Test
    fun upsertPutsNewestFirstAndRemovesDuplicates() {
        val a = file("a.pdf", opened = 1)
        val b = file("b.pdf", opened = 2)
        val aAgain = a.copy(openedAtMillis = 3)
        val result = RecentFilesLogic.upsert(listOf(b, a), aAgain)
        assertEquals(listOf(aAgain, b), result)
    }

    @Test
    fun upsertCapsTheListLength() {
        val existing = (1..5).map { file("f$it.pdf") }
        val result = RecentFilesLogic.upsert(existing, file("new.pdf"), max = 3)
        assertEquals(3, result.size)
        assertEquals("new.pdf", result.first().name)
    }

    @Test
    fun removeDropsOnlyThatUri() {
        val a = file("a.pdf")
        val b = file("b.pdf")
        assertEquals(listOf(b), RecentFilesLogic.remove(listOf(a, b), a.uri))
    }

    @Test
    fun filtersByNameIgnoringCase() {
        val files = listOf(file("Invoice.pdf"), file("notes.pdf"))
        assertEquals(listOf("Invoice.pdf"), RecentFilesLogic.filterAndSort(files, " INVO ", RecentSort.NAME).map { it.name })
    }

    @Test
    fun sortsByDateNameAndSize() {
        val a = file("b.pdf", size = 10, opened = 1)
        val b = file("A.pdf", size = 30, opened = 2)
        val c = file("c.pdf", size = 20, opened = 3)
        val all = listOf(a, b, c)
        assertEquals(listOf("c.pdf", "A.pdf", "b.pdf"), RecentFilesLogic.filterAndSort(all, "", RecentSort.DATE).map { it.name })
        assertEquals(listOf("A.pdf", "b.pdf", "c.pdf"), RecentFilesLogic.filterAndSort(all, "", RecentSort.NAME).map { it.name })
        assertEquals(listOf("A.pdf", "c.pdf", "b.pdf"), RecentFilesLogic.filterAndSort(all, "", RecentSort.SIZE).map { it.name })
    }
}
