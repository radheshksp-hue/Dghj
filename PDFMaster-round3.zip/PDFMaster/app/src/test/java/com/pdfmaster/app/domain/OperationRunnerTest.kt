package com.pdfmaster.app.domain

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class OperationRunnerTest {

    @Test
    fun startsIdle() = runTest {
        val runner = OperationRunner<Int>(this)
        assertEquals(OperationState.Idle, runner.state.value)
    }

    @Test
    fun movesFromRunningToCompleted() = runTest {
        val runner = OperationRunner<Int>(this)
        assertTrue(runner.start { 42 })
        assertTrue(runner.state.value is OperationState.Running)
        advanceUntilIdle()
        assertEquals(OperationState.Completed(42), runner.state.value)
    }

    @Test
    fun ignoresASecondStartWhileRunning() = runTest {
        val runner = OperationRunner<Int>(this)
        val gate = CompletableDeferred<Unit>()
        assertTrue(runner.start { gate.await(); 1 })
        assertFalse(runner.start { 2 })
        gate.complete(Unit)
        advanceUntilIdle()
        assertEquals(OperationState.Completed(1), runner.state.value)
    }

    @Test
    fun failuresBecomeReadableMessages() = runTest {
        val runner = OperationRunner<Int>(this)
        runner.start { throw AppException(AppException.Kind.INVALID_PDF, "Damaged file.") }
        advanceUntilIdle()
        assertEquals(OperationState.Failed("Damaged file."), runner.state.value)
    }

    @Test
    fun cancellationEndsInCancelledNotFailed() = runTest {
        val runner = OperationRunner<Int>(this)
        runner.start { delay(10_000); 1 }
        runCurrent()
        runner.cancel()
        advanceUntilIdle()
        assertEquals(OperationState.Cancelled, runner.state.value)
    }

    @Test
    fun cancellingBeforeTheJobStartsStillEndsCancelled() = runTest {
        val runner = OperationRunner<Int>(this)
        runner.start { 1 }
        runner.cancel()
        advanceUntilIdle()
        assertEquals(OperationState.Cancelled, runner.state.value)
    }

    @Test
    fun reportsRealProgress() = runTest {
        val runner = OperationRunner<Int>(this)
        val gate = CompletableDeferred<Unit>()
        runner.start { report ->
            report(OperationProgress(1, 4, "Step 1"))
            gate.await()
            1
        }
        runCurrent()
        val running = runner.state.value as OperationState.Running
        assertEquals("Step 1", running.progress?.label)
        assertEquals(0.25f, running.progress?.fraction)
        gate.complete(Unit)
        advanceUntilIdle()
    }

    @Test
    fun canRunAgainAfterCompletionAndReset() = runTest {
        val runner = OperationRunner<Int>(this)
        runner.start { 1 }
        advanceUntilIdle()
        runner.reset()
        assertEquals(OperationState.Idle, runner.state.value)
        assertTrue(runner.start { 2 })
        advanceUntilIdle()
        assertEquals(OperationState.Completed(2), runner.state.value)
    }

    @Test
    fun resetDoesNothingWhileRunning() = runTest {
        val runner = OperationRunner<Int>(this)
        val gate = CompletableDeferred<Unit>()
        runner.start { gate.await(); 1 }
        runner.reset()
        assertTrue(runner.state.value is OperationState.Running)
        gate.complete(Unit)
        advanceUntilIdle()
    }

    @Test
    fun progressFractionIsNullWithoutKnownTotal() {
        assertEquals(null, OperationProgress(0, 0, "x").fraction)
        assertEquals(1f, OperationProgress(9, 3, "x").fraction)
    }
}
