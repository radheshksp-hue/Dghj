package com.pdfmaster.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class PageEditorStateTest {

    private fun PageEditorState.order() = pages.map { it.sourceIndex }

    private fun PageEditorState.select(vararg ids: Long) = copy(selected = ids.toSet())

    @Test
    fun startsUnchangedInSourceOrder() {
        val state = PageEditorState.initial(5)
        assertEquals(listOf(0, 1, 2, 3, 4), state.order())
        assertFalse(state.hasChanges)
        assertFalse(state.canUndo)
    }

    @Test
    fun rotationAccumulatesAndWrapsAround() {
        var state = PageEditorState.initial(2).select(0)
        repeat(4) { state = state.rotateSelected(90) }
        assertEquals(0, state.pages[0].rotation)
        state = state.rotateSelected(-90)
        assertEquals(270, state.pages[0].rotation)
        assertEquals(0, state.pages[1].rotation)
        assertTrue(state.hasChanges)
    }

    @Test
    fun rotationWithNothingSelectedDoesNothing() {
        val state = PageEditorState.initial(3)
        assertSame(state, state.rotateSelected(90))
    }

    @Test
    fun deleteRemovesSelectedPagesOnly() {
        val state = PageEditorState.initial(5).select(1, 3).deleteSelected()
        assertEquals(listOf(0, 2, 4), state.order())
        assertTrue(state.selected.isEmpty())
        assertTrue(state.hasChanges)
    }

    @Test
    fun deleteRefusesToRemoveEveryPage() {
        val state = PageEditorState.initial(3).selectAll()
        assertSame(state, state.deleteSelected())
    }

    @Test
    fun moveEarlierSwapsWithNeighbour() {
        val state = PageEditorState.initial(5).select(2).moveSelected(-1)
        assertEquals(listOf(0, 2, 1, 3, 4), state.order())
    }

    @Test
    fun moveEarlierAtStartChangesNothing() {
        val state = PageEditorState.initial(5).select(0)
        val moved = state.moveSelected(-1)
        assertSame(state, moved)
        assertFalse(moved.canUndo)
    }

    @Test
    fun moveLaterMovesAContiguousBlockTogether() {
        val state = PageEditorState.initial(5).select(1, 2).moveSelected(1)
        assertEquals(listOf(0, 3, 1, 2, 4), state.order())
    }

    @Test
    fun moveLaterMovesSeparatedSelectionsIndependently() {
        val state = PageEditorState.initial(5).select(0, 2).moveSelected(1)
        assertEquals(listOf(1, 0, 3, 2, 4), state.order())
    }

    @Test
    fun duplicateInsertsCopyAfterEachSelectedPage() {
        val state = PageEditorState.initial(3).select(1).duplicateSelected()
        assertEquals(listOf(0, 1, 1, 2), state.order())
        val ids = state.pages.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertEquals(setOf(1L), state.selected)
    }

    @Test
    fun duplicateKeepsRotationOfTheOriginal() {
        val state = PageEditorState.initial(2).select(0).rotateSelected(90).duplicateSelected()
        assertEquals(listOf(90, 90, 0), state.pages.map { it.rotation })
    }

    @Test
    fun reverseFlipsTheWholeOrder() {
        val state = PageEditorState.initial(4).reverse()
        assertEquals(listOf(3, 2, 1, 0), state.order())
    }

    @Test
    fun oddAndEvenSelectByCurrentPosition() {
        val state = PageEditorState.initial(5).reverse()
        // Order is 4,3,2,1,0 so odd positions hold source pages 4, 2, 0.
        val odd = state.selectOdd().selectedPages.map { it.sourceIndex }
        val even = state.selectEven().selectedPages.map { it.sourceIndex }
        assertEquals(listOf(4, 2, 0), odd)
        assertEquals(listOf(3, 1), even)
    }

    @Test
    fun undoAndRedoWalkTheHistory() {
        val original = PageEditorState.initial(3)
        val edited = original.select(0).rotateSelected(90).reverse()
        val undone = edited.undo().undo()
        assertEquals(original.pages, undone.pages)
        assertFalse(undone.hasChanges)
        val redone = undone.redo().redo()
        assertEquals(edited.pages, redone.pages)
    }

    @Test
    fun newEditClearsRedoHistory() {
        val state = PageEditorState.initial(3).select(0).rotateSelected(90).undo()
        assertTrue(state.canRedo)
        val next = state.rotateSelected(180)
        assertFalse(next.canRedo)
    }

    @Test
    fun undoDropsSelectionOfPagesThatNoLongerExist() {
        val state = PageEditorState.initial(3).select(0).duplicateSelected()
        val copyId = state.pages[1].id
        val selected = state.copy(selected = setOf(copyId))
        assertEquals(emptySet<Long>(), selected.undo().selected)
    }

    @Test
    fun entriesDescribeTheOutput() {
        val state = PageEditorState.initial(3).select(1).rotateSelected(90).deleteSelected().let {
            it.select(0).rotateSelected(270)
        }
        assertEquals(
            listOf(PageEntry(0, 270), PageEntry(2, 0)),
            state.entries(),
        )
    }

    @Test
    fun historyIsBounded() {
        var state = PageEditorState.initial(2).select(0)
        repeat(PageEditorState.MAX_HISTORY + 20) { state = state.rotateSelected(90) }
        assertEquals(PageEditorState.MAX_HISTORY, state.undoStack.size)
    }

    @Test
    fun normalizeRotationHandlesNegatives() {
        assertEquals(270, normalizeRotation(-90))
        assertEquals(0, normalizeRotation(360))
        assertEquals(90, normalizeRotation(450))
    }
}
