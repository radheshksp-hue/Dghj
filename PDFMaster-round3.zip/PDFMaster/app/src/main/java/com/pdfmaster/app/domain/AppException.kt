package com.pdfmaster.app.domain

/**
 * An error whose [message] is already written for the person using the app.
 * Everything that can fail in a predictable way throws this, so the UI never has to guess.
 */
class AppException(
    val kind: Kind,
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause) {

    enum class Kind {
        SOURCE_UNAVAILABLE,
        ENCRYPTED,
        INVALID_PDF,
        INVALID_INPUT,
        INSUFFICIENT_STORAGE,
        VERIFICATION_FAILED,
        DESTINATION_FAILED,
    }
}
