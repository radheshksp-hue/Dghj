package com.pdfmaster.app.print

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

/** Hands the original PDF bytes to the Android print system. Copying runs off the main thread. */
class PdfPrintAdapter(
    private val context: Context,
    private val uri: Uri,
    private val documentName: String,
) : PrintDocumentAdapter() {

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: Bundle?,
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        val info = PrintDocumentInfo.Builder(documentName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()
        callback.onLayoutFinished(info, newAttributes != oldAttributes)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback,
    ) {
        val cancelled = AtomicBoolean(false)
        cancellationSignal?.setOnCancelListener { cancelled.set(true) }

        Thread {
            try {
                val input = context.contentResolver.openInputStream(uri)
                if (input == null) {
                    callback.onWriteFailed("The document could not be opened for printing.")
                    return@Thread
                }
                input.use { source ->
                    FileOutputStream(destination.fileDescriptor).use { sink ->
                        val buffer = ByteArray(64 * 1024)
                        while (!cancelled.get()) {
                            val read = source.read(buffer)
                            if (read < 0) break
                            sink.write(buffer, 0, read)
                        }
                    }
                }
                if (cancelled.get()) {
                    callback.onWriteCancelled()
                } else {
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                }
            } catch (e: IOException) {
                callback.onWriteFailed("The document could not be sent to the printer.")
            } catch (e: SecurityException) {
                callback.onWriteFailed("Access to the document was denied.")
            }
        }.start()
    }
}
