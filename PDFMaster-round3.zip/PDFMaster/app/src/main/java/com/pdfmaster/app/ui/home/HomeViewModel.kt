package com.pdfmaster.app.ui.home

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.RecentFile
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val container: AppContainer) : ViewModel() {

    /** null while the stored list is still loading, so the empty state doesn't flash. */
    val recents: StateFlow<List<RecentFile>?> = container.recents.recents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun keepAccess(uri: Uri) {
        container.access.persistRead(uri)
    }

    /** Removes the entry from the list only. The file itself is never deleted. */
    fun removeFromRecents(file: RecentFile) {
        viewModelScope.launch {
            container.recents.remove(file.uri)
            container.access.releaseRead(Uri.parse(file.uri))
        }
    }
}
