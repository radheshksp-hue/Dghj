package com.pdfmaster.app.ui.tools

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.domain.OperationState
import com.pdfmaster.app.domain.SizeFormat
import com.pdfmaster.app.domain.SplitMode
import com.pdfmaster.app.domain.SplitPlanResult
import com.pdfmaster.app.domain.SplitPlanner
import com.pdfmaster.app.ui.components.MessageCard

@Composable
fun SplitScreen(
    container: AppContainer,
    uri: Uri,
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
) {
    val viewModel: SplitViewModel = viewModel(
        key = "split:$uri",
        factory = viewModelFactory { initializer { SplitViewModel(container, uri) } },
    )
    val load by viewModel.load.collectAsStateWithLifecycle()
    val processing by viewModel.processing.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Split & extract") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        when (val state = load) {
            SplitLoad.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }

            is SplitLoad.Error -> Box(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                MessageCard(message = state.message, isError = true)
            }

            is SplitLoad.Ready -> {
                var mode by rememberSaveable { mutableStateOf(SplitMode.EXTRACT) }
                var rangeText by rememberSaveable { mutableStateOf("") }
                val plan = remember(mode, rangeText, state.pageCount) {
                    SplitPlanner.plan(mode, rangeText, state.pageCount)
                }
                val needsRanges = mode != SplitMode.EACH_PAGE

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = padding.calculateTopPadding() + 8.dp,
                        bottom = padding.calculateBottomPadding() + 24.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(state.info.displayName, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                                Text(
                                    "${state.pageCount} ${if (state.pageCount == 1) "page" else "pages"} · " +
                                        SizeFormat.format(state.info.sizeBytes),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            ModeOption(
                                selected = mode == SplitMode.EXTRACT,
                                title = "Extract pages into one PDF",
                                description = "Example: 1-3, 7, 10- keeps those pages together in one new file.",
                                onSelect = { mode = SplitMode.EXTRACT },
                            )
                            ModeOption(
                                selected = mode == SplitMode.RANGES,
                                title = "Split into separate PDFs by range",
                                description = "Each range becomes its own file: 1-3, 4-6 makes two files.",
                                onSelect = { mode = SplitMode.RANGES },
                            )
                            ModeOption(
                                selected = mode == SplitMode.EACH_PAGE,
                                title = "Save every page as its own PDF",
                                description = "Creates one file per page.",
                                onSelect = { mode = SplitMode.EACH_PAGE },
                            )
                        }
                    }
                    if (needsRanges) {
                        item {
                            val error = (plan as? SplitPlanResult.Error)?.message
                            OutlinedTextField(
                                value = rangeText,
                                onValueChange = { rangeText = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Pages") },
                                placeholder = { Text("e.g. 1-3, 5, 8-") },
                                singleLine = true,
                                isError = rangeText.isNotBlank() && error != null,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                                supportingText = {
                                    Text(
                                        if (rangeText.isNotBlank() && error != null) error
                                        else "Pages 1 to ${state.pageCount}. Use commas between entries and a dash for ranges.",
                                    )
                                },
                            )
                        }
                    }
                    item {
                        PlanPreview(plan)
                    }
                    item {
                        Button(
                            onClick = { viewModel.start(mode, rangeText) },
                            enabled = plan is SplitPlanResult.Success && processing !is OperationState.Running,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            val count = (plan as? SplitPlanResult.Success)?.groups?.size ?: 0
                            Text(
                                when {
                                    count <= 1 -> "Create PDF"
                                    else -> "Create $count PDFs"
                                },
                            )
                        }
                    }
                    item {
                        ToolOutput(viewModel = viewModel, onOpenPdf = onOpenPdf)
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeOption(
    selected: Boolean,
    title: String,
    description: String,
    onSelect: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, role = Role.RadioButton, onClick = onSelect)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        RadioButton(selected = selected, onClick = null, modifier = Modifier.padding(top = 2.dp, end = 12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun PlanPreview(plan: SplitPlanResult) {
    if (plan !is SplitPlanResult.Success) return
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val count = plan.groups.size
            Text(
                "Preview: ${if (count == 1) "1 file" else "$count files"} will be created",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            plan.groups.take(PREVIEW_LIMIT).forEach { group ->
                Text(
                    "${group.label} · ${group.pages.size} ${if (group.pages.size == 1) "page" else "pages"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
            if (count > PREVIEW_LIMIT) {
                Text(
                    "and ${count - PREVIEW_LIMIT} more",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
        }
    }
}

private const val PREVIEW_LIMIT = 6
