package com.pdfmaster.app

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.pdfmaster.app.domain.RecentFile
import com.pdfmaster.app.pdf.PdfEngine
import com.pdfmaster.app.settings.SettingsRepository
import com.pdfmaster.app.storage.DocumentAccess
import com.pdfmaster.app.storage.DocumentInfo
import com.pdfmaster.app.storage.RecentFilesRepository
import com.pdfmaster.app.storage.ResultSaver
import com.pdfmaster.app.storage.TempFiles
import java.io.File

private val Context.appDataStore: DataStore<Preferences> by preferencesDataStore(name = "pdf_master")

/** Hand-wired dependency container: small enough that a DI framework would only add build risk. */
class AppContainer(val appContext: Context) {
    val access = DocumentAccess(appContext)
    val temp = TempFiles(appContext)
    val engine = PdfEngine(access, temp)
    val resultSaver = ResultSaver(access)
    val settings = SettingsRepository(appContext.appDataStore)
    val recents = RecentFilesRepository(appContext.appDataStore)

    fun resultUri(file: File): Uri =
        FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)

    /**
     * Adds a document to "Recent files", but only when read access can be kept across restarts.
     * Documents handed over temporarily by other apps are not listed because they would be dead links later.
     */
    suspend fun rememberDocument(info: DocumentInfo) {
        if (access.persistRead(info.uri)) {
            recents.add(RecentFile(info.uri.toString(), info.displayName, info.sizeBytes, System.currentTimeMillis()))
        }
    }
}
