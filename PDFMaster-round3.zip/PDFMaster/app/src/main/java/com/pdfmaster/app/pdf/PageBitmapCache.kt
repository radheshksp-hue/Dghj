package com.pdfmaster.app.pdf

import android.graphics.Bitmap
import android.util.LruCache

/** Memory-bounded cache of rendered pages, keyed by page index and render width. */
class PageBitmapCache(maxBytes: Int) {

    private val cache = object : LruCache<String, Bitmap>(maxBytes) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(pageIndex: Int, widthPx: Int): Bitmap? = cache.get(key(pageIndex, widthPx))

    fun put(pageIndex: Int, widthPx: Int, bitmap: Bitmap) {
        cache.put(key(pageIndex, widthPx), bitmap)
    }

    fun clear() {
        cache.evictAll()
    }

    private fun key(pageIndex: Int, widthPx: Int) = "$pageIndex@$widthPx"

    companion object {
        /** An eighth of the app heap, capped, so scrolling a big PDF can't exhaust memory. */
        fun createDefault(): PageBitmapCache {
            val budget = (Runtime.getRuntime().maxMemory() / 8).coerceAtMost(96L * 1024 * 1024)
            return PageBitmapCache(budget.toInt())
        }
    }
}
