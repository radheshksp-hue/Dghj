package com.pdfmaster.app.domain

/** A page in the editor. [rotation] is the extra rotation applied by the user, 0/90/180/270. */
data class PageItem(val id: Long, val sourceIndex: Int, val rotation: Int = 0)

/** One page of the output: which source page (0-based) and how much extra rotation to add. */
data class PageEntry(val sourceIndex: Int, val rotationDelta: Int)

fun normalizeRotation(degrees: Int): Int = ((degrees % 360) + 360) % 360

/**
 * Immutable state of the page organizer with undo/redo.
 * Selection changes are not part of the history; page changes are.
 */
data class PageEditorState(
    val pages: List<PageItem>,
    val selected: Set<Long> = emptySet(),
    val undoStack: List<List<PageItem>> = emptyList(),
    val redoStack: List<List<PageItem>> = emptyList(),
    val nextId: Long = pages.size.toLong(),
    val originalCount: Int = pages.size,
) {
    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()
    val selectedCount: Int get() = selected.size
    val selectedPages: List<PageItem> get() = pages.filter { it.id in selected }

    val hasChanges: Boolean
        get() = pages.size != originalCount ||
            pages.withIndex().any { (index, page) -> page.sourceIndex != index || page.rotation != 0 }

    fun entries(): List<PageEntry> = pages.map { PageEntry(it.sourceIndex, it.rotation) }

    // ---- selection ----

    fun toggle(id: Long): PageEditorState {
        if (pages.none { it.id == id }) return this
        return copy(selected = if (id in selected) selected - id else selected + id)
    }

    fun selectAll(): PageEditorState = copy(selected = pages.map { it.id }.toSet())

    fun clearSelection(): PageEditorState = if (selected.isEmpty()) this else copy(selected = emptySet())

    /** Pages in positions 1, 3, 5, ... of the current order. */
    fun selectOdd(): PageEditorState =
        copy(selected = pages.filterIndexed { index, _ -> index % 2 == 0 }.map { it.id }.toSet())

    /** Pages in positions 2, 4, 6, ... of the current order. */
    fun selectEven(): PageEditorState =
        copy(selected = pages.filterIndexed { index, _ -> index % 2 == 1 }.map { it.id }.toSet())

    // ---- edits ----

    fun rotateSelected(deltaDegrees: Int): PageEditorState {
        if (selected.isEmpty()) return this
        val updated = pages.map {
            if (it.id in selected) it.copy(rotation = normalizeRotation(it.rotation + deltaDegrees)) else it
        }
        return commit(updated)
    }

    /** Refuses to delete every page: a document needs at least one. */
    fun deleteSelected(): PageEditorState {
        if (selected.isEmpty()) return this
        val remaining = pages.filterNot { it.id in selected }
        if (remaining.isEmpty()) return this
        return commit(remaining, newSelected = emptySet())
    }

    /** Moves every selected page one place earlier (-1) or later (+1). */
    fun moveSelected(direction: Int): PageEditorState {
        if (selected.isEmpty() || direction == 0) return this
        val list = pages.toMutableList()
        var moved = false
        if (direction < 0) {
            for (i in 1 until list.size) {
                if (list[i].id in selected && list[i - 1].id !in selected) {
                    val tmp = list[i]; list[i] = list[i - 1]; list[i - 1] = tmp
                    moved = true
                }
            }
        } else {
            for (i in list.size - 2 downTo 0) {
                if (list[i].id in selected && list[i + 1].id !in selected) {
                    val tmp = list[i]; list[i] = list[i + 1]; list[i + 1] = tmp
                    moved = true
                }
            }
        }
        return if (moved) commit(list) else this
    }

    /** Inserts a copy right after each selected page. The originals stay selected. */
    fun duplicateSelected(): PageEditorState {
        if (selected.isEmpty()) return this
        var id = nextId
        val result = ArrayList<PageItem>(pages.size + selected.size)
        for (page in pages) {
            result += page
            if (page.id in selected) result += page.copy(id = id++)
        }
        return commit(result, newNextId = id)
    }

    fun reverse(): PageEditorState = if (pages.size < 2) this else commit(pages.reversed())

    // ---- history ----

    fun undo(): PageEditorState {
        if (undoStack.isEmpty()) return this
        val previous = undoStack.last()
        val ids = previous.map { it.id }.toSet()
        return copy(
            pages = previous,
            selected = selected.intersect(ids),
            undoStack = undoStack.dropLast(1),
            redoStack = redoStack + listOf(pages),
        )
    }

    fun redo(): PageEditorState {
        if (redoStack.isEmpty()) return this
        val next = redoStack.last()
        val ids = next.map { it.id }.toSet()
        return copy(
            pages = next,
            selected = selected.intersect(ids),
            undoStack = undoStack + listOf(pages),
            redoStack = redoStack.dropLast(1),
        )
    }

    private fun commit(
        newPages: List<PageItem>,
        newSelected: Set<Long> = selected,
        newNextId: Long = nextId,
    ): PageEditorState = copy(
        pages = newPages,
        selected = newSelected,
        undoStack = (undoStack + listOf(pages)).takeLast(MAX_HISTORY),
        redoStack = emptyList(),
        nextId = newNextId,
    )

    companion object {
        const val MAX_HISTORY = 50

        fun initial(pageCount: Int): PageEditorState =
            PageEditorState(pages = (0 until pageCount).map { PageItem(id = it.toLong(), sourceIndex = it) })
    }
}
