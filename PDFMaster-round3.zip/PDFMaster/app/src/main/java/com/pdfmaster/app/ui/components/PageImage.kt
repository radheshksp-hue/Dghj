package com.pdfmaster.app.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.pdfmaster.app.pdf.PageBitmapCache
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import kotlinx.coroutines.CancellationException

sealed interface PageImageState {
    data object Loading : PageImageState
    data class Ready(val bitmap: Bitmap) : PageImageState
    data object Failed : PageImageState
}

/**
 * Renders [pageIndex] at [widthPx] on a background thread. A previous bitmap of the same page stays
 * visible while a sharper one is being produced, so zooming never flashes empty pages.
 */
@Composable
fun rememberPageImage(
    renderer: PdfDocumentRenderer,
    cache: PageBitmapCache,
    pageIndex: Int,
    widthPx: Int,
): State<PageImageState> = produceState<PageImageState>(
    initialValue = cache.get(pageIndex, widthPx)?.let { PageImageState.Ready(it) } ?: PageImageState.Loading,
    renderer,
    pageIndex,
    widthPx,
) {
    val cached = cache.get(pageIndex, widthPx)
    if (cached != null) {
        value = PageImageState.Ready(cached)
        return@produceState
    }
    try {
        val bitmap = renderer.render(pageIndex, widthPx)
        cache.put(pageIndex, widthPx, bitmap)
        value = PageImageState.Ready(bitmap)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        value = PageImageState.Failed
    }
}

@Composable
fun PdfPageImage(
    renderer: PdfDocumentRenderer,
    cache: PageBitmapCache,
    pageIndex: Int,
    widthPx: Int,
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
    contentScale: ContentScale = ContentScale.Fit,
) {
    val state by rememberPageImage(renderer, cache, pageIndex, widthPx)
    Box(
        modifier = modifier.background(Color.White),
        contentAlignment = Alignment.Center,
    ) {
        when (val current = state) {
            is PageImageState.Ready -> {
                val image = remember(current.bitmap) { current.bitmap.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = contentDescription,
                    modifier = Modifier.matchParentSize(),
                    contentScale = contentScale,
                )
            }

            PageImageState.Failed -> Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = "This page couldn't be displayed",
                tint = Color(0xFF9E9E9E),
                modifier = Modifier.size(24.dp),
            )

            PageImageState.Loading -> CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                strokeWidth = 2.dp,
            )
        }
    }
}
