package com.pdfmaster.app.storage

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.pdfmaster.app.domain.AppException
import com.pdfmaster.app.domain.SizeFormat
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException

data class DocumentInfo(
    val uri: Uri,
    val displayName: String,
    /** -1 when the provider did not report a size. */
    val sizeBytes: Long,
)

/**
 * Every touch of a user's file goes through here: Storage Access Framework URIs only,
 * no broad storage permission, and failures are translated into [AppException]s.
 */
class DocumentAccess(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    /** Reads name and size, which also proves the document can still be reached. */
    fun describe(uri: Uri): DocumentInfo {
        if (uri.scheme == "file") {
            val file = File(uri.path ?: throw unavailable(null))
            if (!file.isFile || !file.canRead()) throw unavailable(null)
            return DocumentInfo(uri, file.name, file.length())
        }
        try {
            resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null,
                null,
                null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    val name = if (nameIndex >= 0 && !cursor.isNull(nameIndex)) cursor.getString(nameIndex) else null
                    val size = if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) cursor.getLong(sizeIndex) else -1L
                    return DocumentInfo(uri, name?.takeIf { it.isNotBlank() } ?: fallbackName(uri), size)
                }
            }
        } catch (e: RuntimeException) {
            throw unavailable(e)
        }
        throw unavailable(null)
    }

    /** Keeps read access to [uri] across app restarts. Returns false when the provider refuses. */
    fun persistRead(uri: Uri): Boolean = try {
        resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        true
    } catch (e: RuntimeException) {
        false
    }

    fun releaseRead(uri: Uri) {
        try {
            resolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: RuntimeException) {
            // Nothing was persisted for this URI; nothing to release.
        }
    }

    fun openForRead(uri: Uri): ParcelFileDescriptor {
        try {
            return resolver.openFileDescriptor(uri, "r") ?: throw unavailable(null)
        } catch (e: FileNotFoundException) {
            throw unavailable(e)
        } catch (e: SecurityException) {
            throw unavailable(e)
        }
    }

    /** Streams [uri] into [destination]. [checkCancelled] is called between chunks. */
    fun copyToFile(uri: Uri, destination: File, checkCancelled: () -> Unit = {}) {
        try {
            val input = resolver.openInputStream(uri) ?: throw unavailable(null)
            input.use { source ->
                FileOutputStream(destination).use { sink ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    while (true) {
                        val read = source.read(buffer)
                        if (read < 0) break
                        sink.write(buffer, 0, read)
                        checkCancelled()
                    }
                }
            }
        } catch (e: FileNotFoundException) {
            throw unavailable(e)
        } catch (e: SecurityException) {
            throw unavailable(e)
        } catch (e: IOException) {
            if (isNoSpace(e)) throw outOfSpace(e)
            throw AppException(
                AppException.Kind.SOURCE_UNAVAILABLE,
                "The file couldn't be read completely. It may be stored online and unavailable right now.",
                e,
            )
        }
    }

    fun ensureFreeSpace(dir: File, requiredBytes: Long) {
        if (requiredBytes <= 0) return
        val free = try {
            StatFs(dir.absolutePath).availableBytes
        } catch (e: IllegalArgumentException) {
            return
        }
        if (free < requiredBytes + SAFETY_MARGIN_BYTES) {
            throw AppException(
                AppException.Kind.INSUFFICIENT_STORAGE,
                "Not enough free storage. About ${SizeFormat.format(requiredBytes)} is needed temporarily. " +
                    "Free some space and try again.",
            )
        }
    }

    /**
     * Writes [source] into [destination], then reads the destination back and compares sizes.
     * @return the number of bytes verified at the destination.
     */
    fun copyFileToUri(source: File, destination: Uri, checkCancelled: () -> Unit = {}): Long {
        try {
            val output = resolver.openOutputStream(destination, "wt")
                ?: throw AppException(
                    AppException.Kind.DESTINATION_FAILED,
                    "The chosen location can't be written to. Pick a different location.",
                )
            output.use { sink ->
                FileInputStream(source).use { input ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        sink.write(buffer, 0, read)
                        checkCancelled()
                    }
                }
            }
        } catch (e: FileNotFoundException) {
            throw destinationFailed(e)
        } catch (e: SecurityException) {
            throw destinationFailed(e)
        } catch (e: IOException) {
            if (isNoSpace(e)) throw outOfSpace(e)
            throw destinationFailed(e)
        }

        val written = countBytes(destination)
        if (written != source.length()) {
            throw AppException(
                AppException.Kind.VERIFICATION_FAILED,
                "The saved file doesn't match the result (expected ${source.length()} bytes, found $written). " +
                    "It was not saved correctly; please try again or choose another location.",
            )
        }
        return written
    }

    fun createInTree(treeUri: Uri, name: String, mimeType: String): Uri {
        try {
            val parent = DocumentsContract.buildDocumentUriUsingTree(
                treeUri,
                DocumentsContract.getTreeDocumentId(treeUri),
            )
            return DocumentsContract.createDocument(resolver, parent, mimeType, name)
                ?: throw AppException(
                    AppException.Kind.DESTINATION_FAILED,
                    "Couldn't create \"$name\" in the chosen folder. Pick a different folder.",
                )
        } catch (e: RuntimeException) {
            throw destinationFailed(e)
        } catch (e: FileNotFoundException) {
            throw destinationFailed(e)
        }
    }

    fun listChildNames(treeUri: Uri): Set<String> {
        val names = mutableSetOf<String>()
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(
                treeUri,
                DocumentsContract.getTreeDocumentId(treeUri),
            )
            resolver.query(
                children,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null,
                null,
                null,
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    cursor.getString(0)?.let { names += it }
                }
            }
        } catch (e: RuntimeException) {
            // Listing is only used to avoid name clashes; the provider renames on conflict anyway.
        }
        return names
    }

    fun deleteQuietly(uri: Uri) {
        try {
            DocumentsContract.deleteDocument(resolver, uri)
        } catch (e: Exception) {
            // Best effort cleanup of a partially written file.
        }
    }

    /** A human-readable place for a saved document, e.g. "Internal storage/Download/merged.pdf". */
    fun friendlyLocation(uri: Uri): String = try {
        val id = if (DocumentsContract.isDocumentUri(context, uri)) DocumentsContract.getDocumentId(uri) else null
        when {
            uri.authority == "com.android.providers.downloads.documents" -> "Downloads"
            id == null -> uri.toString()
            id.startsWith("primary:") -> "Internal storage/" + id.removePrefix("primary:")
            id.contains(':') -> id.replace(':', '/')
            else -> id
        }
    } catch (e: RuntimeException) {
        uri.toString()
    }

    private fun countBytes(uri: Uri): Long {
        return try {
            resolver.openInputStream(uri).use { stream ->
                if (stream == null) return -1L
                val buffer = ByteArray(BUFFER_SIZE)
                var total = 0L
                while (true) {
                    val read = stream.read(buffer)
                    if (read < 0) break
                    total += read
                }
                total
            }
        } catch (e: IOException) {
            -1L
        } catch (e: SecurityException) {
            -1L
        }
    }

    private fun fallbackName(uri: Uri): String = uri.lastPathSegment?.substringAfterLast('/') ?: "document.pdf"

    private fun isNoSpace(e: IOException): Boolean {
        val message = e.message ?: return false
        return message.contains("ENOSPC") || message.contains("No space left", ignoreCase = true)
    }

    private fun unavailable(cause: Throwable?) = AppException(
        AppException.Kind.SOURCE_UNAVAILABLE,
        "This file can't be opened. It may have been moved, renamed or deleted, or access was removed. " +
            "Pick the file again to continue.",
        cause,
    )

    private fun outOfSpace(cause: Throwable) = AppException(
        AppException.Kind.INSUFFICIENT_STORAGE,
        "The device ran out of storage space. Free some space and try again.",
        cause,
    )

    private fun destinationFailed(cause: Throwable) = AppException(
        AppException.Kind.DESTINATION_FAILED,
        "The file couldn't be written to the chosen location. Pick a different location and try again.",
        cause,
    )

    private companion object {
        const val BUFFER_SIZE = 64 * 1024
        const val SAFETY_MARGIN_BYTES = 8L * 1024 * 1024
    }
}
