package com.pdfmaster.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdfmaster.app.ui.navigation.AppNavHost
import com.pdfmaster.app.ui.theme.PdfMasterTheme

class MainActivity : ComponentActivity() {

    private var incomingUri by mutableStateOf<Uri?>(null)
    private var themeReady by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        // Keep the splash up until the saved theme is known, so the UI never flashes the wrong theme.
        splash.setKeepOnScreenCondition { !themeReady }

        val container = (application as PdfMasterApp).container
        if (savedInstanceState == null) incomingUri = pdfUriFrom(intent)

        setContent {
            val storedMode by container.settings.themeMode.collectAsStateWithLifecycle(initialValue = null)
            val mode = storedMode
            LaunchedEffect(mode) { if (mode != null) themeReady = true }

            if (mode != null) {
                val dark = mode.isDark(isSystemInDarkTheme())
                DisposableEffect(dark) {
                    val style = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark }
                    enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                    onDispose { }
                }
                PdfMasterTheme(darkTheme = dark) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background,
                    ) {
                        AppNavHost(
                            container = container,
                            incomingUri = incomingUri,
                            onIncomingHandled = { incomingUri = null },
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pdfUriFrom(intent)?.let { incomingUri = it }
    }

    private fun pdfUriFrom(intent: Intent?): Uri? =
        intent?.takeIf { it.action == Intent.ACTION_VIEW }?.data
}
