package com.pdfmaster.app.ui.reader

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.pdfmaster.app.AppContainer
import com.pdfmaster.app.pdf.PageBitmapCache
import com.pdfmaster.app.pdf.PdfDocumentRenderer
import com.pdfmaster.app.ui.components.MessageCard
import com.pdfmaster.app.ui.components.PdfPageImage
import com.pdfmaster.app.ui.util.Intents
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private const val MIN_ZOOM = 1f
private const val MAX_ZOOM = 3f
private const val ZOOM_STEP = 0.25f

@Composable
fun ReaderScreen(
    container: AppContainer,
    uri: Uri,
    onBack: () -> Unit,
) {
    val viewModel: ReaderViewModel = viewModel(
        key = "reader:$uri",
        factory = viewModelFactory { initializer { ReaderViewModel(container, uri) } },
    )
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val listState = rememberLazyListState()
    var showPages by rememberSaveable { mutableStateOf(false) }
    val ready = state as? ReaderUiState.Ready

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ready?.info?.displayName ?: "PDF", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (ready != null) {
                        IconButton(onClick = { showPages = true }) {
                            Icon(Icons.Filled.GridView, contentDescription = "Show page thumbnails")
                        }
                        IconButton(onClick = { Intents.sharePdfs(context, listOf(uri)) }) {
                            Icon(Icons.Filled.Share, contentDescription = "Share")
                        }
                        IconButton(onClick = { Intents.print(context, uri, ready.info.displayName) }) {
                            Icon(Icons.Filled.Print, contentDescription = "Print")
                        }
                    }
                },
            )
        },
    ) { padding ->
        when (val current = state) {
            ReaderUiState.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }

            is ReaderUiState.Error -> Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                MessageCard(message = current.message, isError = true)
                if (current.canRemoveFromRecents) {
                    TextButton(onClick = {
                        viewModel.removeFromRecents()
                        onBack()
                    }) { Text("Remove from recent files") }
                }
            }

            is ReaderUiState.Ready -> ReaderContent(
                renderer = current.renderer,
                cache = viewModel.cache,
                listState = listState,
                modifier = Modifier.fillMaxSize().padding(padding),
            )
        }
    }

    if (showPages && ready != null) {
        PagesSheet(
            renderer = ready.renderer,
            cache = viewModel.cache,
            listState = listState,
            onDismiss = { showPages = false },
        )
    }
}

@Composable
private fun ReaderContent(
    renderer: PdfDocumentRenderer,
    cache: PageBitmapCache,
    listState: LazyListState,
    modifier: Modifier = Modifier,
) {
    var zoom by rememberSaveable { mutableStateOf(MIN_ZOOM) }
    var showJump by rememberSaveable { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val horizontalScroll = rememberScrollState()
    val currentPage by remember { derivedStateOf { listState.firstVisibleItemIndex + 1 } }

    Column(modifier) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val pagePadding = 8.dp
            val contentWidth = maxWidth * zoom
            val renderWidthPx = with(density) { quantize((contentWidth - pagePadding * 2).roundToPx()) }

            Box(Modifier.fillMaxSize().horizontalScroll(horizontalScroll)) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.width(contentWidth).fillMaxHeight(),
                    contentPadding = PaddingValues(pagePadding),
                    verticalArrangement = Arrangement.spacedBy(pagePadding),
                ) {
                    items(count = renderer.pageCount, key = { it }) { index ->
                        PdfPageImage(
                            renderer = renderer,
                            cache = cache,
                            pageIndex = index,
                            widthPx = renderWidthPx,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(renderer.pageSizes[index].aspect),
                            contentDescription = "Page ${index + 1} of ${renderer.pageCount}",
                        )
                    }
                }
            }
        }

        Surface(tonalElevation = 3.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(
                    onClick = { scope.launch { listState.animateScrollToItem((currentPage - 2).coerceAtLeast(0)) } },
                    enabled = currentPage > 1,
                ) { Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Previous page") }

                TextButton(onClick = { showJump = true }) {
                    Text("$currentPage / ${renderer.pageCount}")
                }

                IconButton(
                    onClick = {
                        scope.launch { listState.animateScrollToItem(currentPage.coerceAtMost(renderer.pageCount - 1)) }
                    },
                    enabled = currentPage < renderer.pageCount,
                ) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Next page") }

                Spacer(Modifier.weight(1f))

                IconButton(
                    onClick = { zoom = (zoom - ZOOM_STEP).coerceAtLeast(MIN_ZOOM) },
                    enabled = zoom > MIN_ZOOM,
                ) { Icon(Icons.Filled.ZoomOut, contentDescription = "Zoom out") }

                TextButton(onClick = { zoom = MIN_ZOOM }) {
                    Text(if (zoom == MIN_ZOOM) "Fit width" else "${(zoom * 100).roundToInt()}%")
                }

                IconButton(
                    onClick = { zoom = (zoom + ZOOM_STEP).coerceAtMost(MAX_ZOOM) },
                    enabled = zoom < MAX_ZOOM,
                ) { Icon(Icons.Filled.ZoomIn, contentDescription = "Zoom in") }
            }
        }
    }

    if (showJump) {
        JumpToPageDialog(
            pageCount = renderer.pageCount,
            onDismiss = { showJump = false },
            onJump = { page ->
                showJump = false
                scope.launch { listState.scrollToItem(page - 1) }
            },
        )
    }
}

@Composable
private fun JumpToPageDialog(
    pageCount: Int,
    onDismiss: () -> Unit,
    onJump: (Int) -> Unit,
) {
    var text by rememberSaveable { mutableStateOf("") }
    val page = text.toIntOrNull()
    val valid = page != null && page in 1..pageCount
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Go to page") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(6) },
                singleLine = true,
                label = { Text("Page (1 to $pageCount)") },
                isError = text.isNotEmpty() && !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (page != null) onJump(page) }, enabled = valid) { Text("Go") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun PagesSheet(
    renderer: PdfDocumentRenderer,
    cache: PageBitmapCache,
    listState: LazyListState,
    onDismiss: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val current = listState.firstVisibleItemIndex
    ModalBottomSheet(onDismissRequest = onDismiss) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(96.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(count = renderer.pageCount) { index ->
                val isCurrent = index == current
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable(onClickLabel = "Go to page ${index + 1}") {
                        scope.launch { listState.scrollToItem(index) }
                        onDismiss()
                    },
                ) {
                    PdfPageImage(
                        renderer = renderer,
                        cache = cache,
                        pageIndex = index,
                        widthPx = 240,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(renderer.pageSizes[index].aspect)
                            .border(
                                BorderStroke(
                                    if (isCurrent) 3.dp else 1.dp,
                                    if (isCurrent) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outlineVariant,
                                ),
                            ),
                        contentDescription = "Page ${index + 1} thumbnail",
                    )
                    Text("${index + 1}", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

/** Rounds up to a multiple of 64 so small layout changes don't trigger a re-render of every page. */
private fun quantize(px: Int): Int = ((px.coerceAtLeast(1) + 63) / 64) * 64
