package com.pdfmaster.app.ui.navigation

import android.net.Uri
import com.pdfmaster.app.domain.UriArg

/** Screens and their routes. Single-document screens carry the document URI as a Base64 argument. */
object Routes {
    const val ARG = "arg"

    const val HOME = "home"
    const val SETTINGS = "settings"
    const val MERGE = "merge"
    const val READER = "reader/{$ARG}"
    const val SPLIT = "split/{$ARG}"
    const val ORGANIZE = "organize/{$ARG}"

    fun reader(uri: Uri) = "reader/${UriArg.encode(uri.toString())}"
    fun split(uri: Uri) = "split/${UriArg.encode(uri.toString())}"
    fun organize(uri: Uri) = "organize/${UriArg.encode(uri.toString())}"
}
