package com.pdfmaster.app.domain

import java.util.Base64

/**
 * Navigation routes cannot carry raw URIs safely, so they travel as URL-safe Base64.
 * The alphabet (A-Z a-z 0-9 - _) contains nothing that needs escaping.
 */
object UriArg {
    fun encode(uri: String): String =
        Base64.getUrlEncoder().withoutPadding().encodeToString(uri.toByteArray(Charsets.UTF_8))

    fun decode(arg: String): String =
        String(Base64.getUrlDecoder().decode(arg), Charsets.UTF_8)
}
