package com.pdfmaster.app.storage

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.pdfmaster.app.domain.RecentFile
import com.pdfmaster.app.domain.RecentFilesCodec
import com.pdfmaster.app.domain.RecentFilesLogic
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

class RecentFilesRepository(private val store: DataStore<Preferences>) {

    val recents: Flow<List<RecentFile>> = store.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { RecentFilesCodec.decode(it[KEY]) }

    suspend fun add(file: RecentFile) {
        store.edit { prefs ->
            val updated = RecentFilesLogic.upsert(RecentFilesCodec.decode(prefs[KEY]), file)
            prefs[KEY] = RecentFilesCodec.encode(updated)
        }
    }

    suspend fun remove(uri: String) {
        store.edit { prefs ->
            val updated = RecentFilesLogic.remove(RecentFilesCodec.decode(prefs[KEY]), uri)
            prefs[KEY] = RecentFilesCodec.encode(updated)
        }
    }

    suspend fun clear() {
        store.edit { it.remove(KEY) }
    }

    private companion object {
        val KEY = stringPreferencesKey("recent_files")
    }
}
