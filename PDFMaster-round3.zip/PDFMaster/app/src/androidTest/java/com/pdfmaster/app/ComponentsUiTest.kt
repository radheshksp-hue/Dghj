package com.pdfmaster.app

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.pdfmaster.app.ui.components.MessageCard
import com.pdfmaster.app.ui.components.ProgressCard
import com.pdfmaster.app.ui.components.ToolCard
import com.pdfmaster.app.ui.home.PdfTool
import com.pdfmaster.app.ui.theme.PdfMasterTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ComponentsUiTest {

    @get:Rule
    val rule = createComposeRule()

    @Test
    fun toolCardShowsItsTitleAndReactsToTaps() {
        var clicked = false
        rule.setContent {
            PdfMasterTheme(darkTheme = false) {
                ToolCard(tool = PdfTool.MERGE, onClick = { clicked = true })
            }
        }
        rule.onNodeWithText("Merge PDFs").assertIsDisplayed().performClick()
        assertTrue(clicked)
    }

    @Test
    fun progressCardShowsItsLabelAndCancelWorks() {
        var cancelled = false
        rule.setContent {
            PdfMasterTheme(darkTheme = true) {
                ProgressCard(label = "Reading report.pdf", fraction = 0.5f, onCancel = { cancelled = true })
            }
        }
        rule.onNodeWithText("Reading report.pdf").assertIsDisplayed()
        rule.onNodeWithText("Cancel").performClick()
        assertTrue(cancelled)
    }

    @Test
    fun errorMessageIsShownAndCanBeDismissed() {
        var dismissed = false
        rule.setContent {
            PdfMasterTheme(darkTheme = false) {
                MessageCard(message = "That file is password-protected.", isError = true, onDismiss = { dismissed = true })
            }
        }
        rule.onNodeWithText("That file is password-protected.").assertIsDisplayed()
        rule.onNodeWithText("Dismiss").performClick()
        assertTrue(dismissed)
    }
}
