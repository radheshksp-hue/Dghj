# Feature status — round 1

**Read this first:** the Android code (everything that uses Android, Compose or PDFBox) has not been compiled by Gradle yet. The pure-logic part (`domain/` package) was compiled with the Kotlin compiler outside Gradle and its unit tests were run: 73 of 73 passed (all test classes except `OperationRunnerTest`, which needs the `kotlinx-coroutines-test` library that was not available there).
The environment this was written in had no Android SDK, no Gradle and no device. "Implemented" below means *the code is written and
reviewed by reading*, **not** that it works. The "Test result" column says **Not run** until someone runs it.

Legend — Status: **Implemented (unverified)**, **Not started**, **Out of scope this round**.

## Feature checklist

| Feature | Status | Test written | Test result | Known limitations |
|---|---|---|---|---|
| App shell: theme (light/dark/system), splash, edge-to-edge, navigation | Implemented (unverified) | `ThemeModeTest`, UI component tests | Not run | Strings are in code, no translations |
| Dashboard: search, tools, recent files, sort, remove | Implemented (unverified) | `RecentFilesTest` | Not run | No "frequently used" shortcuts or activity feed yet |
| Open "with" from other apps | Implemented (unverified) | none | Not run | Such files are not added to Recent (Android gives only temporary access) |
| Reader: scroll, zoom 100–300%, fit width, jump to page, thumbnails | Implemented (unverified) | `RenderSizingTest`, `rendererOpensPagesAndProducesBitmaps` | Not run | Zoom by buttons (no pinch); no fit-to-page; no landscape two-page view |
| Reader: text search, select/copy | **Not started** | – | – | Android's `PdfRenderer` has no text layer; needs another library |
| Reader: share, print | Implemented (unverified) | none | Not run | Shares/prints the original file bytes |
| Password-protected PDFs | Out of scope | – | – | Detected and refused with a clear message (round 4) |
| Merge | Implemented (unverified) | `mergeCombinesPagesInTheGivenOrder`, reorder, damaged, protected, missing-file tests | Not run | Uses PDFBox merge; outlines/bookmarks and form data follow PDFBox's merge behaviour, unchecked |
| Split / extract (pages to one file, ranges to files, every page) | Implemented (unverified) | `PageRangesTest`, `SplitPlannerTest`, engine tests | Not run | Output pages lose links, form fields, bookmarks and page labels (see below) |
| Organize pages: select, rotate, delete (confirmed), duplicate, move, reverse, odd/even, undo/redo | Implemented (unverified) | `PageEditorStateTest`, `buildReordersAndRotatesPages` | Not run | Reordering uses "move earlier/later" buttons, not drag and drop |
| Verified output: page count and rotation re-checked before success is shown | Implemented (unverified) | engine tests | Not run | Checks structure, not visual content |
| Save with verification (re-read of the saved copy), share, preview result | Implemented (unverified) | `savedCopyIsVerifiedAndIdentical` | Not run | Destination is chosen *after* processing; folder save for multi-file results |
| Cancel, no duplicate runs, real step progress | Implemented (unverified) | `OperationRunnerTest` | Not run | Cancellation takes effect between steps, not in the middle of one PDFBox call |
| Low-storage pre-check, temp-file cleanup | Implemented (unverified) | none | Not run | Estimate is approximate (3× input size) |
| Settings: theme, clear recents, privacy summary, about | Implemented (unverified) | `ThemeModeTest` | Not run | No default output folder, page size or compression settings yet |
| Remove blank pages, crop, margins, resize pages | Not started | – | – | Planned for a later round |
| Insert pages from another PDF | Not started | – | – | Planned |
| Images ⇄ PDF, PDF → text, other formats | Out of scope this round | – | – | Round 3 |
| Scanner, OCR (English + Hindi) | Out of scope this round | – | – | Round 3 |
| Annotate, text, shapes, signature, stamps, watermark, page numbers | Out of scope this round | – | – | Round 4 |
| Compression, passwords, permissions, metadata | Out of scope this round | – | – | Round 4 |
| AdMob, consent, Play listing assets | Out of scope this round | – | – | Round 5 |
| Gradle wrapper (`gradlew`, `gradle-wrapper.jar`) | Included (official Gradle 8.11.1 files) | – | – | The workflow runs `./gradlew` and validates the wrapper jar through setup-gradle v4; jar checksum not independently verified here |
| GitHub Actions workflow (builds from an uploaded .zip or from plain files) | Rewritten for ./gradlew; project-finding and APK-check shell logic simulated locally (repo, zip, traversal, no project, two zips, doubled path) | – | Full run on GitHub not done yet | Builds the APK first, runs unit tests afterwards (a failing test does not block the APK); instrumented tests are not part of CI |

## Behaviours you should know about

* **What is preserved when pages are rebuilt (split, extract, organize):** page content, size, rotation and visible
  markup annotations. **Not preserved:** hyperlinks, form fields, bookmarks/outline, page labels and tagged-PDF
  structure. This is deliberate: carrying links across would pull the whole source document into every output file.
* **Merge** keeps more structure than the above because it uses PDFBox's own merger, but this has not been checked.
* **Cropping vs. erasing:** no cropping exists yet. When it does, it will be described as hiding, not erasing.
* **Originals are never modified.** Every tool writes a new file.

## Things most likely to need fixing on the first build

These were written from knowledge of the libraries, not checked against them:

1. **Tool/library versions** in `gradle/libs.versions.toml` (AGP 8.10.1, Gradle 8.11.1, Kotlin 2.1.21, Compose BOM
   2025.05.01, PDFBox-Android 2.0.27.0) were chosen to be mutually compatible and to support API 36, but were not
   resolved by Gradle.
2. **PDFBox-Android API names** used in `PdfEngine.kt` (`MemoryUsageSetting.setTempDir`, `PDDocument.load(File,
   MemoryUsageSetting)`, `PDFMergerUtility.mergeDocuments(MemoryUsageSetting)`, `importPage`, annotation helpers).
3. **Material icon names** from `material-icons-extended` (some may need the `AutoMirrored` variant).
4. Small Compose API details (opt-in annotations are enabled globally in `app/build.gradle.kts`).

## Test inventory

Last local check: all `domain/` code compiles; 73 unit tests passed (everything except `OperationRunnerTest`).

* Unit (JVM): `PageRangesTest`, `FileNamingTest`, `SizeFormatTest`, `PageEditorStateTest`, `RecentFilesTest`,
  `SplitPlannerTest`, `RenderSizingTest`, `UriArgTest`, `ThemeModeTest`, `ErrorMessagesTest`, `OperationRunnerTest`
* Instrumented: `PdfEngineInstrumentedTest` (merge, reorder, rotate, split, protected/damaged/missing inputs,
  renderer, verified save), `ComponentsUiTest`
* **Not yet covered:** large files, scanned/Hindi samples (no OCR yet), low-storage and permission-denied paths on a
  real device, full-screen UI flows, accessibility audit, performance measurements.
