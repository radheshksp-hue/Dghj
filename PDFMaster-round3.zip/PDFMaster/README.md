# PDF Master — All PDF Tools

A native Android app (Kotlin, Jetpack Compose, Material 3) for working with PDF files **on your device**.
This is **round 1 of the plan: foundation and core tools.**

> **Honest status:** this source code was written without access to an Android SDK, Gradle or a device. The
> pure-logic part (`domain/`) was compiled and its unit tests passed (73/73); the Android/Compose/PDFBox part has
> **not been compiled by Gradle yet**. Treat the first GitHub build as the first real test. Details are in
> [`FEATURE_STATUS.md`](FEATURE_STATUS.md).

## What works in this round (once it builds)

* Dashboard with search, recent files (sort / search / remove), and tool cards
* PDF reader: scrolling pages, zoom, fit width, page jump, thumbnails, share, print
* Merge PDFs (reorder, remove, validate, verify)
* Split & extract: pages to one file, ranges to separate files, every page as a file
* Organize pages: select, rotate, delete, duplicate, move, reverse, odd/even select, undo/redo
* Light / dark / system theme, privacy summary, "Open with" for PDFs from other apps

Not in this round: conversion, scanning, OCR, editing and signing, compression, passwords, ads.
See `FEATURE_STATUS.md` for the full list.

## What you need

* [Android Studio](https://developer.android.com/studio) (current stable release)
* JDK 17 (Android Studio includes one)
* An Android phone (Android 8.0 or newer) or an emulator
* Internet on first build (Gradle downloads libraries)

## Open it and build a debug APK on your computer

1. Unzip the project.
2. In Android Studio: **File → Open** and choose the `PDFMaster` folder.
3. Wait for **Gradle sync** to finish. Android Studio will offer to install any missing SDK parts (accept).
4. The Gradle wrapper (`gradlew`, `gradle/wrapper/gradle-wrapper.jar`, Gradle 8.11.1) is already included.
5. **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The file appears in
   `app/build/outputs/apk/debug/app-debug.apk`.
6. To run directly: pick a device at the top and press **Run ▶**.

Command line: `./gradlew assembleDebug` (then `./gradlew testDebugUnitTest`)

## Get an APK from GitHub (no Android Studio needed)

The workflow `.github/workflows/build-apk.yml` builds with the project's own `./gradlew` (Gradle 8.11.1, JDK 17).
It uses **one** strategy per run and prints it in the run summary:

* **REPO mode** - a `settings.gradle.kts` is stored in the repository -> the files are built as committed.
* **ZIP mode** - the repository holds no Gradle project, but exactly **one** project `.zip` -> the zip is checked
  (no absolute paths, no `..`, no symlinks), extracted on the runner and built.

**Easiest way (works from a phone or a browser, ZIP mode):**

1. Create an empty repository on GitHub.
2. **Add file -> Upload files**, and drop in **two files**: this project's `.zip` and the separate
   `build-apk.yml` file. Press **Commit changes**.
3. Open `build-apk.yml` in the repository, press the pencil (Edit), and in the file-name box type
   `.github/workflows/` in front of the name, so it reads `.github/workflows/build-apk.yml`.
   Press **Commit changes**. (GitHub creates the hidden folders for you.)
4. Open the **Actions** tab. The build starts by itself (or use **Run workflow**). The first run takes about 5-10 minutes.
5. When the run is green: download `PDFMaster-debug-apk` under **Artifacts** at the bottom of the run page, or
   `PDFMaster-debug.apk` from the repository's **Releases** page (direct download, easiest on a phone).

**Better for later:** upload the extracted project files (or push with git) instead of a zip - then REPO mode is used.
Keep only **one** project `.zip` in the repository; with two, the run stops and tells you so.

**If a run is red:** open it, read the red step and the "Build failed - important lines" summary, and download the
**diagnostics** artifact (full logs and reports; it is uploaded even when the build fails). The APK is built first and
unit tests run afterwards, so a failing test never hides a good APK; the test result is shown in the run summary.
A build only counts as successful when a non-empty APK containing `AndroidManifest.xml` and `classes.dex` exists.

## हिन्दी में: GitHub से APK कैसे बनाएँ (आसान तरीका)

1. GitHub पर नया खाली repository बनाएँ।
2. **Add file → Upload files** दबाएँ और सिर्फ़ **दो फ़ाइलें** डालें: प्रोजेक्ट की `.zip` और अलग से `build-apk.yml`। (repository में **एक ही** project zip रखें।)
3. `build-apk.yml` खोलकर pencil (Edit) दबाएँ और नाम के आगे `.github/workflows/` लिखें, ताकि पूरा नाम `.github/workflows/build-apk.yml` बने। **Commit changes** दबाएँ।
4. **Actions** टैब खोलें। build अपने-आप शुरू होगा (पहली बार 5-10 मिनट)।
5. हरा ✔ आने पर: **Releases** पेज से `PDFMaster-debug.apk` डाउनलोड करें, या run page के नीचे **Artifacts** से।
6. **लाल ✖ आए तो:** run खोलें → लाल step दबाएँ → या run के **Summary** में "Build failed - important lines" वाला हिस्सा देखें। उसका screenshot भेज दें, या **diagnostics** artifact डाउनलोड करके दे दें।

ध्यान रखें: नया zip डालते समय पुराना project zip हटा दें (दो zip होने पर build रुक जाता है और साफ़ संदेश देता है)।

## Install and try the APK

1. Copy the APK (`PDFMaster-debug.apk` from GitHub, or `app-debug.apk` from a local build) to your phone (or download it there).
2. Open it and allow "install from this source" when Android asks.
3. Open **PDF Master** and tap **Open a PDF**.

## Tests

* Unit tests (pure logic: page ranges, file naming, editor undo/redo, operation states, recents…):
  `./gradlew testDebugUnitTest`
* Instrumented tests (real PDFs through the real engine and renderer, plus UI component tests) need a device
  or emulator: `./gradlew connectedDebugAndroidTest`

## Release build (later, not needed for testing)

1. Android Studio → **Build → Generate Signed Bundle / APK**, create a keystore, and keep it **outside** the
   repository (`*.jks` and `keystore.properties` are in `.gitignore`).
2. Choose **Android App Bundle** for Google Play.
3. Before publishing: build and test the release artifact on a real device, fill in the support contact in
   `PRIVACY.md`, check the licence list, and complete Play Console's Data safety form (this version collects no data).
4. The app targets Android 16 (API 36), which Google Play requires for new apps and updates since 31 Aug 2026.

## AdMob

Not included in this round on purpose, so the privacy policy stays simple and true. When it is added it will use
test ad unit IDs in debug builds and read production IDs from configuration, never from source code.

## Project layout

```
app/src/main/java/com/pdfmaster/app/
  domain/    pure Kotlin logic (page ranges, naming, editor state, operation states) - unit tested
  storage/   document picker access, temp files, saving, recent files
  pdf/       PDFBox engine, PdfRenderer wrapper, bitmap cache
  print/     print adapter
  settings/  theme preference
  ui/        theme, navigation, home, reader, tools (merge, split, organize), settings
app/src/test/        unit tests
app/src/androidTest/ instrumented and UI tests
.github/workflows/build-apk.yml
```

Design choices worth knowing: hand-wired dependency container instead of Hilt (less build risk), string routes
with Base64 URI arguments instead of type-safe routes, and UI text kept in code (no translations yet).
