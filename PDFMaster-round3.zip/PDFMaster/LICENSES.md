# Third-party software

Licences below come from each project's published metadata as known when this project was written.
**Re-check them (and the exact versions) before publishing.**

| Component | Version | Used for | Licence |
|---|---|---|---|
| [PDFBox-Android](https://github.com/TomRoush/PdfBox-Android) (port of Apache PDFBox) | 2.0.27.0 | Merging, extracting, rotating and rebuilding PDF pages | Apache License 2.0 |
| AndroidX (Core, Activity, Lifecycle, Navigation, DataStore, SplashScreen) | see `gradle/libs.versions.toml` | App framework | Apache License 2.0 |
| Jetpack Compose and Material 3, Material Icons Extended | via Compose BOM 2025.05.01 | User interface and icons | Apache License 2.0 |
| Kotlin and kotlinx.coroutines | 2.1.21 / 1.10.2 | Language and async processing | Apache License 2.0 |
| Android `PdfRenderer` | part of Android | Displaying pages | Android Open Source Project, Apache License 2.0 |

Notes

* PDFBox-Android bundles resources from Apache PDFBox (for example glyph lists and font metrics). They
  ship under Apache PDFBox's terms; see the upstream `NOTICE` file.
* The launcher icon is an original vector drawing made for this project.
* Test-only libraries (JUnit 4: EPL 1.0; AndroidX Test: Apache 2.0) are not shipped in the APK.
